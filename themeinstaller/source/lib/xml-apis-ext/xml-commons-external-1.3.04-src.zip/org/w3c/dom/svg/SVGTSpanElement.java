
package org.w3c.dom.svg;

public interface SVGTSpanElement extends 
               SVGTextPositioningElement {
}
