
package org.w3c.dom.svg;

public interface SVGFontFaceUriElement extends 
               SVGElement {
}
