
package org.w3c.dom.svg;

public interface SVGTRefElement extends 
               SVGTextPositioningElement,
               SVGURIReference {
}
