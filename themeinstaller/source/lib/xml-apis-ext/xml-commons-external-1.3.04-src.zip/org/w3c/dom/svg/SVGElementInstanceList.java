
package org.w3c.dom.svg;

public interface SVGElementInstanceList {
  public int getLength( );

  public SVGElementInstance item ( int index );
}
