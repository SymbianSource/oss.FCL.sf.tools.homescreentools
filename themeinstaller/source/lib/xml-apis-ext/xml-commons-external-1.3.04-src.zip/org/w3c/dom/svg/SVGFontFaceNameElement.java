
package org.w3c.dom.svg;

public interface SVGFontFaceNameElement extends 
               SVGElement {
}
